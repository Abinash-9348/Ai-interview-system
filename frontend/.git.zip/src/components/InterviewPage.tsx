// ==========================================
// FILE: src/pages/InterviewPage.tsx
// ==========================================

import axios from "axios";

import {
  useEffect,
  useRef,
  useState,
} from "react";

import {
  useParams,
  useSearchParams
} from "react-router-dom";

interface Props {
  socket: any;
}

const InterviewPage = ({
  socket,
}: Props) => {

  // ==========================================
  // ROUTER
  // ==========================================

  const { roomId } =
    useParams();

  const [searchParams] =
    useSearchParams();

  const interviewId =
    searchParams.get(
      "interviewId"
    );

  // ==========================================
  // STATES
  // ==========================================

  const [questions,
    setQuestions] =
    useState<string[]>([]);

  const [currentIndex,
    setCurrentIndex] =
    useState(0);

  const [currentQuestion,
    setCurrentQuestion] =
    useState("");

  const [candidateAnswer,
    setCandidateAnswer] =
    useState("");

  const [isListening,
    setIsListening] =
    useState(false);

  const recognitionRef =
    useRef<any>(null);

  // ==========================================
  // END INTERVIEW
  // ==========================================

  const handleEndInterview =
    () => {

      console.log(
        "ENDING:",
        roomId
      );

      socket.emit(
        "end-interview",
        {
          roomId,
        }
      );

      window.location.href =
        `/code/${roomId}`;
    };

  // ==========================================
  // AUTO START INTERVIEW
  // ==========================================

  useEffect(() => {

    if (
      interviewId
    ) {

      console.log(
        "AUTO START:",
        interviewId
      );

      generateQuestions(
        interviewId
      );
    }

  }, [interviewId]);

  // ==========================================
  // END INTERVIEW LISTENER
  // ==========================================

  useEffect(() => {

    socket.on(
      "end-interview",
      ({ roomId }: { roomId: string }) => {

        console.log(
          "REDIRECTING:",
          roomId
        );

        window.location.href =
          `/code/${roomId}`;
      }
    );

    return () => {

      socket.off(
        "end-interview"
      );
    };

  }, [socket]);

  // ==========================================
  // GENERATE QUESTIONS
  // ==========================================

  const generateQuestions =
    async (
      interviewId: string
    ) => {

      try {

        const res =
          await axios.post(
            `http://localhost:8000/question/askquestion/${interviewId}`
          );

        console.log(
          "FULL RESPONSE:",
          res.data
        );

        const generatedQuestions =
          res.data.data.map(
            (item: any) =>
              item.question
          );

        console.log(
          "QUESTIONS:",
          generatedQuestions
        );

        setQuestions(
          generatedQuestions
        );

        startInterview(
          generatedQuestions
        );

      } catch (error) {

        console.log(
          "API ERROR:",
          error
        );
      }
    };

  // ==========================================
  // START INTERVIEW
  // ==========================================

  const startInterview = (
    questionsData: string[]
  ) => {

    speak(`
      Welcome to the AI interview session.
      Please answer confidently.
      Best of luck.
    `);

    setTimeout(() => {

      askQuestion(
        0,
        questionsData
      );

    }, 5000);
  };

  // ==========================================
  // SPEAK FUNCTION
  // ==========================================

  const speak = (
    text: string,
    startListening = false
  ) => {

    const utterance =
      new SpeechSynthesisUtterance(
        text
      );

    utterance.lang =
      "en-US";

    utterance.rate = 1;

    utterance.pitch = 1;

    if (
      startListening
    ) {

      utterance.onend =
        () => {

          startRecognition();
        };
    }

    speechSynthesis.speak(
      utterance
    );
  };

  // ==========================================
  // ASK QUESTION
  // ==========================================

  const askQuestion = (
    index: number,
    questionsData = questions
  ) => {

    if (
      index >=
      questionsData.length
    ) {

      speak(`
        Interview completed.
        Thank you.
      `);

      return;
    }

    const question =
      questionsData[index];

    setCurrentQuestion(
      question
    );

    speak(
      question,
      true
    );
  };

  // ==========================================
  // SPEECH RECOGNITION
  // ==========================================

  useEffect(() => {

    const SpeechRecognition =
      (
        window as any
      ).SpeechRecognition ||
      (
        window as any
      ).webkitSpeechRecognition;

    const recognition =
      new SpeechRecognition();

    recognition.lang =
      "en-US";

    recognition.continuous =
      false;

    recognition.interimResults =
      false;

    recognition.maxAlternatives =
      1;

    recognition.onstart =
      () => {

        setIsListening(
          true
        );
      };

    recognition.onend =
      () => {

        setIsListening(
          false
        );
      };

    recognition.onerror =
      (event: any) => {

        console.log(
          "Speech Error:",
          event.error
        );
      };

    recognition.onresult =
      async (
        event: any
      ) => {

        const transcript =
          event.results[0][0]
            .transcript;

        console.log(
          "Candidate Answer:",
          transcript
        );

        setCandidateAnswer(
          transcript
        );

        setTimeout(() => {

          nextQuestion();

        }, 2000);
      };

    recognitionRef.current =
      recognition;

  }, []);

  // ==========================================
  // START RECOGNITION
  // ==========================================

  const startRecognition =
    () => {

      if (
        recognitionRef.current
      ) {

        recognitionRef.current.start();
      }
    };

  // ==========================================
  // NEXT QUESTION
  // ==========================================

  const nextQuestion =
    () => {

      const next =
        currentIndex + 1;

      setCurrentIndex(
        next
      );

      askQuestion(
        next
      );
    };

  return (

    <div
      className="
        min-h-screen
        bg-black
        text-white
        flex
        flex-col
        items-center
        justify-center
        px-6
      "
    >

      <h1
        className="
          text-5xl
          font-bold
          mb-10
        "
      >
        AI Interview
      </h1>

      <div
        className="
          w-full
          max-w-4xl
          rounded-2xl
          border
          border-cyan-500/30
          bg-white/5
          p-8
          backdrop-blur-lg
        "
      >

        <h2
          className="
            text-xl
            text-cyan-400
            mb-4
            font-semibold
          "
        >
          Current Question
        </h2>

        <p
          className="
            text-2xl
            leading-relaxed
          "
        >
          {currentQuestion}
        </p>

      </div>

      <div
        className="
          mt-8
          px-6 py-3
          rounded-xl
          border
          border-cyan-500/40
          bg-cyan-500/10
          text-lg
        "
      >

        {
          isListening
            ? "🎤 Listening..."
            : "🤖 AI Speaking..."
        }

      </div>

      <div
        className="
          mt-8
          w-full
          max-w-4xl
          rounded-2xl
          border
          border-white/10
          bg-white/5
          p-6
        "
      >

        <h3
          className="
            text-lg
            text-green-400
            mb-3
            font-semibold
          "
        >
          Candidate Answer
        </h3>

        <p
          className="
            text-lg
            text-white/80
          "
        >
          {candidateAnswer}
        </p>

      </div>

      <button
        onClick={
          handleEndInterview
        }
        className="
          mt-10
          px-8
          py-4
          rounded-2xl
          bg-red-600
          hover:bg-red-700
          text-white
          font-bold
          transition-all
        "
      >
        End Interview
      </button>

    </div>
  );
};

export default InterviewPage;