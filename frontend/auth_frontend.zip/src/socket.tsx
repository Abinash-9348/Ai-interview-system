import { io, Socket } from "socket.io-client";

let socket: Socket | null = null;

export const initsocket = () => {

  // remove dead socket
  if (socket && !socket.connected) {
    socket = null;
  }

  if (socket?.connected) {

    console.log("⚠️ USING EXISTING SOCKET");

    return socket;
  }

  const token =
    localStorage.getItem("token");

  socket = io(
    "http://localhost:8000",
    {

      auth: {
        token,
      },

      withCredentials: true,

      transports: ["websocket"],

      reconnection: false,

      forceNew: true,
    }
  );

  console.log(
    "✅ NEW SOCKET CREATED"
  );

  return socket;
};