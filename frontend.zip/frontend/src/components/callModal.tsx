import { useEffect, useRef, useState } from "react";
import { Socket } from "socket.io-client";

interface Props {
  onClose: () => void;
  socket: Socket;
  roomId: string;
  userId: string;
}

export default function CallModal({ onClose, socket, roomId, userId }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const peerRef = useRef<RTCPeerConnection | null>(null);
  const pendingCandidates = useRef<RTCIceCandidateInit[]>([]);

  // ✅ Step control
  const [callType, setCallType] = useState<"select" | "audio" | "video">(
    "select",
  );

  // ✅ Start camera ONLY when video selected
  // useEffect(() => {
  //   if (callType === "video" || callType === "audio") {

  //     // stop old stream
  //     if (streamRef.current) {
  //       streamRef.current.getTracks().forEach(t => t.stop());
  //     }

  //     navigator.mediaDevices.getUserMedia({
  //       video: callType === "video",
  //       audio: true
  //     }).then((stream) => {
  //       streamRef.current = stream;

  //       if (callType === "video" && videoRef.current) {
  //         videoRef.current.srcObject = stream;
  //       }
  //     });

  //   }
  // }, [callType]);

  // ✅ Cleanup on unmount
  // useEffect(() => {
  //   // 🎥 OFFER
  //   socket.on("video-offer", async ({ offer }) => {
  //     console.log("📥 offer received");

  //     const stream = await navigator.mediaDevices.getUserMedia({
  //       video: true,
  //       audio: true,
  //     });

  //     streamRef.current = stream;

  //     if (videoRef.current) {
  //       videoRef.current.srcObject = stream;
  //     }

  //     createPeer();

  //     stream.getTracks().forEach((track) => {
  //       peerRef.current!.addTrack(track, stream);
  //     });

  //     await peerRef.current!.setRemoteDescription(offer);

  //     // 🔥 flush ICE
  //     pendingCandidates.current.forEach((c) =>
  //       peerRef.current!.addIceCandidate(c),
  //     );
  //     pendingCandidates.current = [];

  //     const answer = await peerRef.current!.createAnswer();
  //     await peerRef.current!.setLocalDescription(answer);

  //     socket.emit("video-answer", { roomId, answer });
  //   });

  //   // 🎥 ANSWER
  //   socket.on("video-answer", async ({ answer }) => {
  //     console.log("📥 answer received");

  //     await peerRef.current!.setRemoteDescription(answer);

  //     // 🔥 flush ICEd
  //     pendingCandidates.current.forEach((c) =>
  //       peerRef.current!.addIceCandidate(c),
  //     );
  //     pendingCandidates.current = [];
  //   });

  //   // ❄️ ICE
  //   socket.on("video-ice-candidate", async ({ candidate }) => {
  //     if (!peerRef.current) return;

  //     if (peerRef.current.remoteDescription) {
  //       await peerRef.current.addIceCandidate(candidate);
  //     } else {
  //       console.log("⏳ queue ICE");
  //       pendingCandidates.current.push(candidate);
  //     }
  //   });

  //   return () => {
  //     socket.off("video-offer");
  //     socket.off("video-answer");
  //     socket.off("video-ice-candidate");
  //   };
  // }, []);

  // ✅ Stop camera & mic
  const stopMediaTracks = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
    }
  };
  const createPeer = () => {
    const peer = new RTCPeerConnection({
      iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
    });

    peer.onconnectionstatechange = () => {
      console.log("🔗 connection:", peer.connectionState);
    };

    peer.oniceconnectionstatechange = () => {
      console.log("❄️ ICE state:", peer.iceConnectionState);
    };

    peer.ontrack = (event) => {
      console.log("🎥 remote stream received", event.streams);

      if (remoteVideoRef.current) {
        remoteVideoRef.current.srcObject = event.streams[0];
      }
    };

    peer.onicecandidate = (event) => {
      if (event.candidate) {
        socket.emit("video-ice-candidate", {
          roomId,
          candidate: event.candidate,
        });
      }
    };

    peerRef.current = peer;
  };

  const startCall = async () => {

    console.log("🔥 CALL CLICKED");
console.log("📤 emitting video-offer", socket.id);
console.log("Socket connected:", socket.connected);
    const stream = await navigator.mediaDevices.getUserMedia({
      video: true,
      audio: true,
    });

    streamRef.current = stream;

    if (videoRef.current) {
      videoRef.current.srcObject = stream;
    }

    createPeer();

    // 🔥 ADD TRACK HERE
    stream.getTracks().forEach((track) => {
      peerRef.current!.addTrack(track, stream);
    });

    const offer = await peerRef.current!.createOffer();
    await peerRef.current!.setLocalDescription(offer);

    socket.emit("video-offer", { roomId, offer, from: userId });
  };

 useEffect(() => {
  if (!socket) return;

  socket.on("video-offer", async ({ offer }) => {
    console.log("📥 offer received");

    const stream = await navigator.mediaDevices.getUserMedia({
      video: true,
      audio: true,
    });

    streamRef.current = stream;

    if (videoRef.current) {
      videoRef.current.srcObject = stream;
    }

    createPeer();

    stream.getTracks().forEach((track) => {
      peerRef.current!.addTrack(track, stream);
    });

    await peerRef.current!.setRemoteDescription(offer);

    const answer = await peerRef.current!.createAnswer();
    await peerRef.current!.setLocalDescription(answer);

    socket.emit("video-answer", { roomId, answer });
  });

  socket.on("video-answer", async ({ answer }) => {
    await peerRef.current!.setRemoteDescription(answer);
  });

  socket.on("video-ice-candidate", async ({ candidate }) => {
    if (!peerRef.current) return;

    if (peerRef.current.remoteDescription) {
      await peerRef.current.addIceCandidate(candidate);
    } else {
      pendingCandidates.current.push(candidate);
    }
  });

  return () => {
    socket.off("video-offer");
    socket.off("video-answer");
    socket.off("video-ice-candidate");
  };
}, [socket]);

  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center">
      <div className="bg-[#111] rounded-2xl p-6 w-[900px] h-[550px] flex flex-col">
        {/* ✅ STEP 1: SELECT CALL TYPE */}
        {callType === "select" && (
          <div className="flex flex-col items-center justify-center h-full space-y-6">
            <h2 className="text-white text-xl font-semibold">
              Choose Call Type
            </h2>

            <div className="flex space-x-6">
              <button
                onClick={async () => {
                  setCallType("audio");

                  const stream = await navigator.mediaDevices.getUserMedia({
                    video: false,
                    audio: true,
                  });

                  streamRef.current = stream;

                  setTimeout(() => {
                    startCall();
                  }, 300); // 🔥
                }}
                className="bg-gray-700 px-6 py-3 rounded-lg text-white"
              >
                🎤 Audio Call
              </button>

              <button
                onClick={async () => {
                  setCallType("video");

                  const stream = await navigator.mediaDevices.getUserMedia({
                    video: true,
                    audio: true,
                  });

                  streamRef.current = stream;

                  if (videoRef.current) {
                    videoRef.current.srcObject = stream;
                  }

                  setTimeout(() => {
                    startCall();
                  }, 200);
                }}
                className="bg-[#00ff88] px-6 py-3 rounded-lg text-black font-semibold"
              >
                🎥 Video Call
              </button>
            </div>

            <button onClick={onClose} className="text-red-500">
              Cancel
            </button>
          </div>
        )}

        {/* ✅ STEP 2: VIDEO CALL UI */}
        {callType === "video" && (
          <>
            <div className="flex-1 grid grid-cols-2 gap-4">
              {/* Your Video */}
              <video
                ref={videoRef}
                autoPlay
                muted
                className="w-full h-full rounded-xl bg-black"
              />

              {/* Remote Placeholder */}
              <video
                ref={remoteVideoRef}
                autoPlay
                playsInline
                className="w-full h-full rounded-xl bg-black"
              />
            </div>

            {/* Controls */}
            <div className="flex justify-center space-x-6 mt-4">
              <button className="bg-gray-700 px-4 py-2 rounded-lg">Mute</button>

              <button className="bg-gray-700 px-4 py-2 rounded-lg">
                Video
              </button>

              <button
                onClick={() => {
                  stopMediaTracks();
                  onClose();
                }}
                className="bg-red-600 px-4 py-2 rounded-lg"
              >
                End Call
              </button>
            </div>
          </>
        )}

        {/* ✅ STEP 3: AUDIO CALL UI */}
        {callType === "audio" && (
          <div className="flex flex-col items-center justify-center h-full space-y-6 text-white">
            <h2 className="text-xl">🎤 Audio Call Started</h2>

            <div className="flex space-x-6">
              <button className="bg-gray-700 px-4 py-2 rounded-lg">Mute</button>

              <button
                onClick={() => {
                  stopMediaTracks();
                  onClose();
                }}
                className="bg-red-600 px-4 py-2 rounded-lg"
              >
                End Call
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
