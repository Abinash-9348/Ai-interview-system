import { Request,Response,NextFunction } from "express";
import jwt  from 'jsonwebtoken'
import { User } from "../model/users.model.ts";



interface JwtPayload {
   id:string
   role:string
   name:string
}
import {
  Request,
  Response,
  NextFunction
} from "express";

import jwt from "jsonwebtoken";

import { User } from "../model/users.model.ts";

interface JwtPayload {
  id: string;
  role: string;
  name: string;
}

export const isValiduser = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {

  try {

    const token =
      req.cookies.accesstoken;

    if (!token) {

      return res.status(401).json({
        msg: "token not found",
      });

    }

    const decode = jwt.verify(
      token,
      process.env.ACCESS_SECRET as string
    ) as JwtPayload;
 console.log("DECODE:", decode)
    const user = await User.findById(
      decode.id
    );

    if (!user) {

      return res.status(404).json({
        msg: "user not found",
      });

    }

    (req as any).user = user;

    next();

  } catch (error) {

    return res.status(401).json({
      msg: "Invalid token",
      error,
    });

  }
};