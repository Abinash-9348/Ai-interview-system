import { Server, Socket } from "socket.io";
import { Message } from "../model/meessage.model.ts";
import { Room } from "../model/room.model.ts";
import { Violation } from "../model/violation.model.ts";
import jwt from 'jsonwebtoken'
import cookie from 'cookie';
import { InterviewResult } from "../model/interview.result.ts";


interface JwtPayload {
   id:string
   name:string
   role:string
}

type User = {
  socketId: string;
  id: string;
  name: string;
  color: string;
};

// State storage
const users: Record<string, User[]> = {};
const pendingUsers: Record<string, User[]> = {};

// Helper to remove user from all rooms
const removeUserFromAll = (socketId: string) => {
  for (const roomId in users) {
    users[roomId] = users[roomId].filter(u => u.socketId !== socketId);
  }
  for (const roomId in pendingUsers) {
    pendingUsers[roomId] = pendingUsers[roomId].filter(u => u.socketId !== socketId);
  }
};

export const initSocket = (io: Server) => {
  io.use((socket: Socket, next) => {
    try {
      const cookies = cookie.parse(socket.handshake.headers.cookie || "");
      const token = cookies.accesstoken;

      if (!token) {
        return next(new Error("Unauthorized"));
      }

      const decoded = jwt.verify(token, process.env.ACCESS_SECRET as string) as JwtPayload;
      socket.data.user = decoded;
      next();
    } catch (error) {
      next(new Error("Invalid token"));
    }
  });

  io.on("connection", (socket: Socket) => {
 socket.onAny((event) => {

      console.log(
        "EVENT:",
        event
      );
    });
    socket.on("join", async ({ roomId, color }) => {
      const room = await Room.findOne({ roomId });
      const user = socket.data.user as JwtPayload;
      socket.data.roomId = roomId;

      if (!room) return;

      const isAdmin = room.createdBy?.userId?.toString() === user.id?.toString();

      if (isAdmin) {
        socket.join(roomId);
        socket.emit("you-are-admin");

        // Send pending users to admin
        if (pendingUsers[roomId]) {
          pendingUsers[roomId].forEach((u) => {
            socket.emit("user-waiting", u);
          });
        }

        if (room.code) {
          socket.emit("code-update", room.code);
        }

        // Add to active users
        if (!users[roomId]) users[roomId] = [];
        users[roomId] = users[roomId].filter(u => u.id !== user.id);
        users[roomId].push({
          socketId: socket.id,
          id: user.id,
          name: user.name,
          color: color || "#ff4d4f",
        });

        io.to(roomId).emit("active-users", users[roomId]);
       
      } else {
        // Candidate logic
        if (!pendingUsers[roomId]) pendingUsers[roomId] = [];
        
        // Prevent duplicate pending entries for same user
        pendingUsers[roomId] = pendingUsers[roomId].filter(u => u.id !== user.id);
        
        const candidate = {
          socketId: socket.id,
          id: user.id,
          name: user.name,
          color: color || "#3178c6",
        };
        
        pendingUsers[roomId].push(candidate);
        
        // Notify room (admins will listen)
        io.to(roomId).emit("user-waiting", candidate);
        socket.emit("waiting-approval");
  
      }
    });

    socket.on("approve-user", async ({ socketId, roomId }) => {
      const admin = socket.data.user as JwtPayload;
      const room = await Room.findOne({ roomId });
      
      if (room?.createdBy?.userId?.toString() !== admin.id?.toString()) {
        return; // Only admin can approve
      }


      io.to(socketId).emit("approved", { roomId });
    });

    socket.on("reject-user", async ({ socketId, roomId }) => {
      const admin = socket.data.user as JwtPayload;
      const room = await Room.findOne({ roomId });

      if (room?.createdBy?.userId?.toString() !== admin.id?.toString()) {
        return;
      }

      io.to(socketId).emit("rejected", { roomId });
      
      if (pendingUsers[roomId]) {
        pendingUsers[roomId] = pendingUsers[roomId].filter(u => u.socketId !== socketId);
      }
    });

    socket.on("approved-join", async ({ roomId, color }) => {
      const user = socket.data.user as JwtPayload;
      
      // Move from pending to active
      if (pendingUsers[roomId]) {
        pendingUsers[roomId] = pendingUsers[roomId].filter(u => u.id !== user.id);
      }

      socket.join(roomId);
      
      if (!users[roomId]) users[roomId] = [];
      users[roomId] = users[roomId].filter(u => u.id !== user.id);
      users[roomId].push({
        socketId: socket.id,
        id: user.id,
        name: user.name,
        color: color || "#ff4d4f",
      });

      io.to(roomId).emit("active-users", users[roomId]);
      io.to(roomId).emit("user-joined", {
        message: `${user.name} joined the room`,
      });
      console.log("👤 USER JOINED:", user.name);
    });

    socket.on("code-change", async ({ roomId, code }) => {
      await Room.findOneAndUpdate({ roomId }, { code });
      socket.to(roomId).emit("code-update", code);
    });

    socket.on("cursor-move", ({ roomId, position }) => {
      const user = socket.data.user as JwtPayload;
      socket.to(roomId).emit("cursor-update", {
        position,
        user: {
          id: user.id,
          name: user.name,
          socketId: socket.id,
        },
      });
    });

    socket.on("send-message", async ({ roomId, message }) => {
      const user = socket.data.user as JwtPayload;
      const newMessage = await Message.create({
        roomId,
        message,
        user: {
          name: user.name,
          color: "#ff4d4f", // Should ideally be retrieved from active users
        },
      });

      io.to(roomId).emit("receive-message", newMessage);
    });

    socket.on("load-messages", async (roomId: string) => {
      const messages = await Message.find({ roomId })
        .sort({ createdAt: -1 })
        .limit(50);
      socket.emit("previous-messages", messages.reverse());
    });

    socket.on("typing", (roomId) => {
      const user = socket.data.user as JwtPayload;
      socket.to(roomId).emit("user-typing", { name: user.name });
    });

    socket.on("stop-typing", (roomId) => {
      const user = socket.data.user as JwtPayload;
      socket.to(roomId).emit("user-stop-typing", { name: user.name });
    });

    // WebRTC Signaling (Targeted)
    socket.on("video-offer", ({ roomId, offer, type, toSocketId }) => {
      const user = socket.data.user as JwtPayload;
      const payload = {
        offer,
        from: {
          id: user.id,
          name: user.name,
          role: user.role,
          socketId: socket.id,
        },
        type,
      };

      if (toSocketId) {
        io.to(toSocketId).emit("video-offer", payload);
      } else {
        socket.to(roomId).emit("video-offer", payload);
      }
    });

    socket.on("video-answer", ({ answer, toSocketId }) => {
      const user = socket.data.user as JwtPayload;
      io.to(toSocketId).emit("video-answer", {
        answer,
        from: { id: user.id, name: user.name, socketId: socket.id },
      });
    });

    socket.on("video-ice-candidate", ({ candidate, toSocketId }) => {
      const user = socket.data.user as JwtPayload;
      io.to(toSocketId).emit("video-ice-candidate", {
        candidate,
        from: { id: user.id, name: user.name, socketId: socket.id },
      });
    });

    socket.on("call-ended", ({ roomId, toSocketId }) => {
      const user = socket.data.user as JwtPayload;
      const payload = { user: { id: user.id, name: user.name } };
      if (toSocketId) {
        io.to(toSocketId).emit("call-ended", payload);
      } else {
        socket.to(roomId).emit("call-ended", payload);
      }
    });

    // Proctoring & Tab events
socket.on(
  "tab-inactive",
  ({ roomId }) => {

    const user =
      socket.data.user as JwtPayload;

    io.to(roomId).emit(
      "user-tab-inactive",
      {
        message:
          `${user.name} switched tab`,
        user,
      }
    );
  }
);

socket.on(
  "tab-active",
  ({ roomId }) => {

    const user =
      socket.data.user as JwtPayload;

    io.to(roomId).emit(
      "user-tab-active",
      {
        message:
          `${user.name} is back`,
        user,
      }
    );
  }
);

    socket.on("violation", async ({ roomId, type }) => {
      const user = socket.data.user as JwtPayload;
      try {
        const violation = await Violation.create({
          roomId,
          userId: user.id,
          username: user.name,
          type,
        });
        socket.to(roomId).emit("violation-alert", violation);
      } catch (error) {
        console.error("Violation save error:", error);
      }
    });

    socket.on("track-time", async ({ roomId, type, duration }) => {
      const user = socket.data.user as JwtPayload;
      try {
        const updateFields: any = {};
        const fieldMap: Record<string, string> = {
          looking_left: "lookingLeftTime",
          looking_right: "lookingRightTime",
          head_movement: "headMovementTime",
          multiple_faces: "multipleFaceTime",
          no_face_detected: "noFaceTime",
        };

        if (fieldMap[type]) {
          updateFields.$inc = { [fieldMap[type]]: duration };
        }

        await Violation.findOneAndUpdate(
          { roomId, userId: user.id },
          { username: user.name, ...updateFields },
          { upsert: true }
        );

        socket.to(roomId).emit("violation-alert", { username: user.name, type });
      } catch (error) {
        console.error("Track time error:", error);
      }
    });

    const handleDisconnect = () => {
      const roomId = socket.data.roomId;
      const user = socket.data.user as JwtPayload;

      if (!roomId) return;

      removeUserFromAll(socket.id);

      io.to(roomId).emit("USER_LEFT", { username: user?.name || "Someone" });
      io.to(roomId).emit("active-users", users[roomId] || []);
      console.log("🔥 Disconnected:", socket.id);
    };

    socket.on("leave-room", (_, callback) => {
      handleDisconnect();
      socket.leave(socket.data.roomId);
      if (callback) callback();
    });

     socket.on(
          "start-interview",
          (data) => {

            console.log(
              "Interview Started"
            );

            io.emit(
              "start-interview",
              data
            );
          }
        );
        socket.on(
  "end-interview",
  (data) => {

    io.emit(
      "end-interview",
      data
    );
  }
);

socket.on(
  "candidate-answer",

  async ({
    roomId,
    question,
    answer,
  }) => {

    try {

      // FIND RESULT
      let result =
        await InterviewResult.findOne({
          roomId,
        });

      // CHECK
      if (!result) {

        console.log(
          "InterviewResult not found"
        );

        result =
    await InterviewResult.create({

      roomId,

      answers: [],
    });
      }

      // PUSH ANSWER
      result.answers.push({

        question,

        answer,

      });

      // SAVE
      await result.save();

      console.log(
        "ANSWER SAVED"
      );

    } catch (error) {

      console.log(error);

    }
  }
);
    socket.on("disconnect", () => {
      handleDisconnect();
    });
  });
};